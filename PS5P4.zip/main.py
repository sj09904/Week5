question = input("Enter continue? ")
counter = 0
totalgrosspay = 0
averagegrosspay = 0

if question == "yes":
  while question == "yes":
    counter = float(counter) + 1
    employeelastname = input("Enter employee lastname ")
    hoursworked = input("Enter hours worked ")
    rateofpay = input("Enter rate of pay ")
    if float(hoursworked) > 40:
      grosspay = float(rateofpay) * 40 + float(rateofpay) * 1.5 * (float(hoursworked) - 40)
    else:
      grosspay = float(hoursworked) * float(rateofpay)
    totalgrosspay = float(totalgrosspay) + float(grosspay)
    print (employeelastname)
    print (grosspay)
    question = input("Enter continue ")

if counter == 0:
  averagegrosspay = 0
else:
  averagegrosspay = float(totalgrosspay) / float(counter)
print (totalgrosspay)
print (counter)
print (averagegrosspay)