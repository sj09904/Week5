start = input("Enter start")
stop = input("Enter stop")
increment = input("increment")

while float(start) <= float(stop):
  print (start)
  start = float(start) + float(increment)
  
