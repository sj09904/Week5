question = input("Enter continue? ")
totaldiscount = 0

if question == "yes":
  while question == "yes":
    quantity = input("Enter quantity ")
    priceofanitem = input("Enter price of an item ")
    extendedprice = float(quantity) * float(priceofanitem)
    if float(extendedprice) > 10000.00:
      discount = .25
    else:
      discount = .10
    discountamount = float(extendedprice) * float(discount)
    total = float(extendedprice) - float(discountamount)
    totaldiscount = float(totaldiscount) + float(discountamount)
    print (extendedprice)
    print (discountamount)
    print (total)
    question = input("Enter continue ")
print (totaldiscount)