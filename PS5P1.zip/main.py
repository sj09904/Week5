count = input("Enter odd number starting at 1")

while float(count) <= 25:
  count = float(count) + 2
  print (count)1
