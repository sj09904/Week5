question = input("Enter continue? ")
counter = 0

if question == "yes":
  while question == "yes":
    counter = float(counter) + 1
    lastname = input("Enter lastname ")
    exam1 = input("Enter exam 1 ")
    exam2 = input("Enter exam 2 ")
    total = (float(exam1) + float(exam2))/ 2
    print (lastname)
    print (total)
    question = input("Enter continue? ")
  else:
    print (counter)